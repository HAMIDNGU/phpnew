<?php

function uploadFile($destDir =  './img/', $allowedTypes = ['image/png', 'image/jpeg']) {
    if(isset($_POST['upload']) && 
        isset($_FILES['file']) && 
        $_FILES['file']['error'] === UPLOAD_ERR_OK
    ) {

        $fileInfo = new finfo(FILEINFO_MIME_TYPE);
        $type = $fileInfo->file($_FILES['file']['tmp_name']);
        //echo $type;

        $ext = '';

        switch ($type) {
            case 'image/png':
                $ext = '.png';
            break;
            case 'image/jpeg':
                $ext = '.jpg';
            break;
        }

        if($ext !== '') {
            $fn = bin2hex(random_bytes(10)).$ext;
            move_uploaded_file($_FILES['file']['tmp_name'], $destDir.$fn);
        }
    }
}

uploadFile();