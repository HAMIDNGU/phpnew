<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Files!</title>
    </head>

    <body>
        <form method="post" action="upload.php" enctype="multipart/form-data">
            <div>
                <span>Select an Image:</span>
                <input type="file" name="file" />
            </div>
            <input type="submit" value="Upload!" name="upload" />
        </form>
    </body>

</html>