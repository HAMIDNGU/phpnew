<?php
require_once('./inc/init.php');


?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="./css/style.css" />
    </head>

    <body>


        <?php
    include('./inc/userManage.php');
    if(isset($user)) {
             
        ?>
        <?php
    }
?>
        <form action="login.php" method="post">
            <input type="hidden" name="action" value="login" />
            <div>
                <div>Username: </div>
                <div>
                    <input type="text" name="username" />
                </div>
                <div>Password: </div>
                <div>
                    <input type="password" name="pass" />
                </div>
                <input type="submit" value="Login" name="submit" />
            </div>
        </form>
        <a href="create_account.php">Create Account</a>

    </body>

</html>