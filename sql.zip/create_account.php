<?php
require_once('./inc/init.php');
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Create Account</title>
        <link rel="stylesheet" href="./css/style.css" />
    </head>

    <body>
        <?php 
            include('./inc/userManage.php');
        ?>
        <h2>Sign Up!</h2>
        <?php

    if(isset($_POST['username']) && isset($_POST['pass']) && 
        isset($_POST['pass_re']) && 
        ($_POST['pass'] === $_POST['pass_re'])
    ) {

        $userult = User::create($_POST['username'],$_POST['pass']);
        echo $userult['msg'];
    } else {

?>
        <form action="create_account.php" method="post" enctype="multipart/form-data">
            <div>
                <div>Username: </div>
                <div>
                    <input type="text" name="username" />
                </div>
                <div>Password: </div>
                <div>
                    <input type="password" name="pass" />
                </div>
                <div>Re-enter Password: </div>
                <div>
                    <input type="password" name="pass_re" />
                </div>
                <div>
                    <span>Select an Image:</span>
                    <input type="file" name="file" />
                </div>
                <input type="submit" value="Create" name="submit" />
            </div>
        </form>
        <?php } ?>
    </body>

</html>