<div id="login-control">
    <?php
    if(isset($user) && $user['status']) {
        echo "<img id=\"profilePhoto\" src=\"./img/profilePhoto.php/?u={$user['user']['username']}\" /> ";
        echo "<div><div>Logged in as: {$user['user']['username']}</div><a href=\"?logout\">Logout</a></div>";
    } else {
?>
    Not logged in <a href="/login/login.php">Login</a>
    <?php } ?>
</div>